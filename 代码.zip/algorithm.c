#include "algorithm.h"

int algo_conv(unsigned short int *data, unsigned int data_size,
              unsigned short int *core, unsigned int core_size)
{
    if (data_size < core_size)
    {
        return -1;
    }

    unsigned long long int core_sum = 0;
    for (int i = 0; i < core_size; ++i)
    {
        core_sum += core[i];
    }

    unsigned long long int data_sum = 0;
    for (int i = 0; i < core_size; ++i)
    {
        data_sum += data[i];
    }

    for (int i = 0; i < data_size - core_size; ++i)
    {
        unsigned long long int sum = 0;
        for (int j = 0; j < core_size; ++j)
        {
            sum += core[j] * data[i + j];
        }
        data[i] = sum / core_sum;
    }

    return 0;
}

int algo_fir_bandpass_gen_core(unsigned int sample_rate, unsigned int low_freq, unsigned int high_freq,
                               unsigned int stage, unsigned short int *fir_core, unsigned int ref_sum)
{
    int de = stage / 2;
    double sum = 0;
    double min = 0;

    for (int i = 0; i < stage; ++i)
    {
        double windows_i = 0.54 - 0.46 * sin((2 * PI * i) / (stage - 1));

        if (i != stage / 2)
        {
            double value = ((sin((i - de) * 2 * PI * high_freq / sample_rate) -
                             sin((i - de) * 2 * PI * low_freq / sample_rate)) /
                            (2 * PI * (i - de))) *
                           windows_i;

            if (value < min)
            {
                min = value;
            }
            sum += value;
        }
    }

    for (int i = 0; i < stage; ++i)
    {
        double windows_i = 0.54 - 0.46 * sin((2 * PI * i) / (stage - 1));

        if (i != stage / 2)
        {
            double value = ((sin((i - de) * 2 * PI * high_freq / sample_rate) -
                             sin((i - de) * 2 * PI * low_freq / sample_rate)) /
                            (2 * PI * (i - de))) *
                               windows_i -
                           min;

            fir_core[i] = value * (ref_sum / (sum - stage * min));
        }
    }
    fir_core[stage / 2] = (fir_core[stage / 2 - 1] + fir_core[stage / 2 + 1]) / 2;

    return 0;
}

int algo_gaussian_gen_core(unsigned int stage, unsigned short int *conv_core,
                           double sig, unsigned int ref_sum)
{
    double u = stage / 2;
    double sum = 0;

    for (int i = 0; i < stage; ++i)
    {
        double y = (0.39894 / sig) * exp(0 - ((pow((i - u), 2)) / (2 * pow(sig, 2))));
        sum += y;
    }

    for (int i = 0; i < stage; ++i)
    {
        double y = (0.39894 / sig) * exp(0 - ((pow((i - u), 2)) / (2 * pow(sig, 2))));
        conv_core[i] = y * (ref_sum / sum);
    }

    return 0;
}

int algo_dc_balance(unsigned short int *data, unsigned int data_size,
                    unsigned int dc_dst, unsigned int dc_bal_length)
{
    if (dc_bal_length > data_size)
    {
        return -1;
    }

    for (int i = 0; i < data_size; ++i)
    {
        static unsigned long long int data_sum;
        if (i < data_size - dc_bal_length)
        {
            data_sum = 0;
            for (int j = 0; j < dc_bal_length; ++j)
            {
                data_sum += data[i + j];
            }
        }

        data[i] -= (data_sum / dc_bal_length - dc_dst);
    }

    return 0;
}

int algo_del_higher_value(unsigned short int *data, unsigned int data_size,
                          unsigned short int threshold)
{
    for (int i = 0; i < data_size; ++i)
    {
        if (data[i] > threshold)
        {
            data[i] = threshold;
        }
    }
    return 0;
}

int algo_stat(unsigned short int *data, unsigned int data_size, unsigned short int threshold, unsigned int *stat,
              unsigned int *algo_stat_thresholds)
{
    int stat_flag = 0;
    unsigned int sum = 0;
    unsigned int fromer_index = 0;
    for (int i = 0; i < data_size; ++i)
    {
        if (stat_flag == 1)
        {
            if (data[i] < threshold)
            {
                stat_flag = 1;
                sum += threshold - data[i];
            }
            else
            {
                unsigned int stat_val = sum / (i - fromer_index);

                if ((stat_val >= algo_stat_thresholds[0]) && (stat_val < algo_stat_thresholds[ALGO_STAT_THRESHOLDS_LENGTH - 1]))
                {
                    for (int i = 0; i < ALGO_STAT_THRESHOLDS_LENGTH - 1; ++i)
                    {
                        if ((stat_val >= algo_stat_thresholds[i]) && (stat_val < algo_stat_thresholds[i + 1]))
                        {
                            ++stat[i];
                        }
                    }
                }
                else
                {
                    ++stat[ALGO_STAT_THRESHOLDS_LENGTH - 1];
                }

                stat_flag = 0;
                sum = 0;
            }
        }
        else
        {
            if (data[i] < threshold)
            {
                stat_flag = 1;
                sum += threshold - data[i];
                fromer_index = i;
            }
            else
            {
                stat_flag = 0;
                sum = 0;
            }
        }
    }

    return 0;
}
