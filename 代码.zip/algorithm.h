#ifndef ALGORITHM_H
#define ALGORITHM_H

#include <math.h>

#include "main.h"

#define PI 3.1415926535f
#define ALGO_STAT_THRESHOLDS_LENGTH 8

#define ALGO_THRESHOLD_DEFAULT 1850

int algo_conv(unsigned short int *data, unsigned int data_size,
              unsigned short int *core, unsigned int core_size);

int algo_fir_bandpass_gen_core(unsigned int sample_rate, unsigned int low_freq, unsigned int high_freq,
                               unsigned int stage, unsigned short int *fir_core, unsigned int ref_sum);

int algo_gaussian_gen_core(unsigned int stage, unsigned short int *conv_core,
                           double sig, unsigned int ref_sum);

int algo_dc_balance(unsigned short int *data, unsigned int data_size,
                    unsigned int dc_dst, unsigned int dc_bal_length);

int algo_del_higher_value(unsigned short int *data, unsigned int data_size,
                          unsigned short int threshold);

int algo_stat(unsigned short int *data, unsigned int data_size, unsigned short int threshold, unsigned int *stat,
              unsigned int *algo_stat_thresholds);

#endif
